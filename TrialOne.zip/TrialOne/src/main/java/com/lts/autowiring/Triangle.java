package com.lts.autowiring;

import org.springframework.stereotype.Component;

@Component
public class Triangle implements Shape {

	@Override
	public void calculateArea(int x, int y) {
		// TODO Auto-generated method stub
			System.out.println("Area of Triangle="+1/2.0*x*y);
	}

}
