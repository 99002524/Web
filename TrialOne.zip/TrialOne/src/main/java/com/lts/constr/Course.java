package com.lts.constr;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Course {
	String CourseName;
	double CoursePrice;
	
	public String getName() {
		return CourseName;
	}
	
	@Value("${student.course.CourseName}")
	public void setName(String name) {
		this.CourseName = name;
	}
	public double getPrice() {
		return CoursePrice;
	}
	
	@Value("${student.course.CoursePrice}")
	public void setPrice(double price) {
		this.CoursePrice = price;
	}
	
	@Override
	public String toString() {
		return "Course [name=" + CourseName + ", price=" + CoursePrice + "]";
	}
	
	
}
